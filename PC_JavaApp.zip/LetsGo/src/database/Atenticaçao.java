package database;
//PROGRAMA DESENVOLVIDO POR: 
//WYLKERD SANTOS SILVA / RA: N294HH-0 / TURMA: CC4A41
import javax.swing.JOptionPane;

public class Atentica�ao {
	String login = "wylkerd@hotmail.com";
	String senha = "12345678";
	String in_login , in_Senha = "";
			
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getIn_login() {
		return in_login;
	}

	public void setIn_login(String in_login) {
		this.in_login = in_login;
	}

	public String getIn_Senha() {
		return in_Senha;
	}

	public void setIn_Senha(String in_Senha) {
		this.in_Senha = in_Senha;
	}
	
	public void verAutentica�ao (){
		try{
			
			if (this.getIn_login().equals(this.getLogin()) && this.getIn_Senha().equals(this.getSenha())){
				JOptionPane.showMessageDialog(null, "Acesso liberado");
				VisualDB abrir = new VisualDB();
				abrir.setVisible(true);
			} else {
				JOptionPane.showMessageDialog(null, "Acesso negado. Login e senha incorretos !");

			}
			
			
		} catch (Exception e){
			
		}
	}
	
}
