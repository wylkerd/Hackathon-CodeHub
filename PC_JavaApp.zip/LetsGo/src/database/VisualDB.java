package database;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.JTabbedPane;
import javax.swing.border.LineBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Component;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;

public class VisualDB extends JFrame {

	private static JPanel contentPane;
	private static JTable table_2;
	private static JTable table_3;
	private JTextField txtns;
	private JTextField txtprop;
	private JTextField txtec;
	private JTextField txtp;
	private JTextField txtc;
	private JTextField txtt;
	private JTextField txtteu;
	private JTextField txtem;
	private JTextField txtds3;
	private JTextField txtnserie3;
	private JTextField txtpos3;
	
	public static Connection getConnection() throws Exception {
		try {
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/testdb";
			String username = "root";
			String password = "root";
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url,username,password);
			System.out.println("connected");
			return conn;
		}catch(Exception e){System.out.println(e);}
		return null;
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VisualDB frame = new VisualDB();
					Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				    frame.setBounds(0,0,screenSize.width, screenSize.height - 40); 
					frame.setVisible(true);
					UIManager.setLookAndFeel(new com.jtattoo.plaf.graphite.GraphiteLookAndFeel());
					DisplayDB2(); 
					DisplayDB();
					frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public VisualDB() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1359, 689);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnAdd = new JButton("Adicionar");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Connection conobj;
				try {
					conobj = getConnection();
					String query = "INSERT INTO `contt` VALUES ("+txtns.getText()+", '"+txtprop.getText()+"', '"+txtec.getText()+"', "+txtp.getText()+", '"+txtc.getText()+"', '"+txtt.getText()+"', "+txtteu.getText()+", '"+txtem.getText()+"');";
					PreparedStatement stmt = conobj.prepareStatement(query);
					stmt.executeUpdate();
					DisplayDB();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		});
		btnAdd.setBounds(470, 521, 97, 32);
		contentPane.add(btnAdd);
		
		JButton btnDel = new JButton("Deletar");
		btnDel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int row = table_2.getSelectedRow();
				String cell = table_2.getModel().getValueAt(row, 0).toString();
				String sql = "DELETE FROM `contt` WHERE n_serie = " + cell;
				try{
					Connection conobj = getConnection();
					PreparedStatement del = conobj.prepareStatement(sql);
					del.execute();
					DisplayDB();
				}catch(Exception e){System.out.println(e);}
			}
		});
		
		JButton btnNewButton = new JButton("Mover");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new JOptionPane();
					String op = JOptionPane.showInputDialog(null, "Procurar por Numero de Serie", "");
					Connection conobj = getConnection();
					String query = "INSERT INTO `contp`(n_serie2, propiet2, est_cheg2, peso2, cont2, tipo2, teus2, email2) SELECT * FROM `contt` WHERE n_serie = "+ op;
					PreparedStatement stmt = conobj.prepareStatement(query);
					stmt.executeUpdate();
					
					String update = "UPDATE `contp` SET data_cheg2 = CURRENT_TIMESTAMP() WHERE n_serie2 = "+ op;
					PreparedStatement stmt2 = conobj.prepareStatement(update);
					stmt2.executeUpdate();
					DisplayDB2();
					/*try
					{String query2 = "SELECT `pos2` FROM `contp` WHERE n_serie2 = "+ op;
					ResultSet rs = stmt.executeQuery(query2);
					for(int i = 0; i < 16; i++)
					{}
					}catch(Exception e1){System.out.println(e1);};*/
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		
		JButton btnDel3 = new JButton("Deletar");
		btnDel3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int row3 = table_3.getSelectedRow();
				String cell3 = table_3.getModel().getValueAt(row3, 0).toString();
				String sql3 = "DELETE FROM `contp` WHERE n_serie2 = " + cell3;
				try{
					Connection conobj3 = getConnection();
					PreparedStatement del3 = conobj3.prepareStatement(sql3);
					del3.execute();
					DisplayDB2();
				}catch(Exception e){System.out.println(e);}
			}
		});
		
		JButton btnupd = new JButton("Atualizar");
		btnupd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Connection conobj;
				try {
					conobj = getConnection();
					String updpos = "UPDATE `contp` SET data_s2 = '"+txtds3.getText()+"', pos2 = '"+txtpos3.getText()+"' WHERE n_serie2 = "+ txtnserie3.getText();
					PreparedStatement stmt3 = conobj.prepareStatement(updpos);
					stmt3.executeUpdate();
					DisplayDB2();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		btnupd.setBounds(1201, 521, 111, 32);
		contentPane.add(btnupd);
		
		btnDel3.setBounds(1201, 564, 111, 32);
		contentPane.add(btnDel3);
		
		btnNewButton.setBounds(470, 607, 97, 32);
		contentPane.add(btnNewButton);
		
		btnDel.setBounds(470, 564, 97, 32);
		contentPane.add(btnDel);
		
		JScrollPane scrollPane = new JScrollPane(table_2);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(46, 32, 521, 478);
		contentPane.add(scrollPane);
		
		JScrollPane scrollPane3 = new JScrollPane(table_3);
		scrollPane3.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane3.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane3.setBounds(675, 32, 637, 478);
		contentPane.add(scrollPane3);
		
		Color colorCyan = new Color(3, 238, 255);
		Color colorPurple = new Color(35, 1, 129);
		
		contentPane.setBackground(Color.white);
		
		table_2 = new JTable();
		scrollPane.setViewportView(table_2);
		
		table_2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		table_3 = new JTable();
		scrollPane3.setViewportView(table_3);
		
		table_3.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		txtns = new JTextField();
		txtns.setBounds(122, 524, 127, 20);
		contentPane.add(txtns);
		txtns.setColumns(10);
		
		txtprop = new JTextField();
		txtprop.setColumns(10);
		txtprop.setBounds(122, 555, 127, 20);
		contentPane.add(txtprop);
		
		txtec = new JTextField();
		txtec.setColumns(10);
		txtec.setBounds(122, 588, 127, 20);
		contentPane.add(txtec);
		
		txtp = new JTextField();
		txtp.setColumns(10);
		txtp.setBounds(122, 619, 127, 20);
		contentPane.add(txtp);
		
		txtc = new JTextField();
		txtc.setColumns(10);
		txtc.setBounds(333, 524, 127, 20);
		contentPane.add(txtc);
		
		txtt = new JTextField();
		txtt.setColumns(10);
		txtt.setBounds(333, 555, 127, 20);
		contentPane.add(txtt);
		
		txtteu = new JTextField();
		txtteu.setColumns(10);
		txtteu.setBounds(333, 588, 127, 20);
		contentPane.add(txtteu);
		
		JLabel lblNDeSerie = new JLabel("RFID");
		lblNDeSerie.setForeground(Color.BLACK);
		lblNDeSerie.setBounds(46, 524, 59, 14);
		contentPane.add(lblNDeSerie);
		
		JLabel lblPropietarios = new JLabel("Propietarios");
		lblPropietarios.setForeground(Color.BLACK);
		lblPropietarios.setBounds(46, 558, 75, 14);
		contentPane.add(lblPropietarios);
		
		JLabel lblEstCheg = new JLabel("Est. Cheg");
		lblEstCheg.setForeground(Color.BLACK);
		lblEstCheg.setBounds(46, 591, 64, 14);
		contentPane.add(lblEstCheg);
		
		JLabel lblPesokg = new JLabel("Peso(kg)");
		lblPesokg.setForeground(Color.BLACK);
		lblPesokg.setBounds(46, 622, 59, 14);
		contentPane.add(lblPesokg);
		
		JLabel label_4 = new JLabel("Conteudo");
		label_4.setForeground(Color.BLACK);
		label_4.setBounds(259, 524, 59, 14);
		contentPane.add(label_4);
		
		JLabel lblTipoDeCarga = new JLabel("Tipo Carga");
		lblTipoDeCarga.setForeground(Color.BLACK);
		lblTipoDeCarga.setBounds(259, 558, 75, 14);
		contentPane.add(lblTipoDeCarga);
		
		JLabel label_2 = new JLabel("TEUs");
		label_2.setForeground(Color.BLACK);
		label_2.setBounds(259, 591, 64, 14);
		contentPane.add(label_2);
		
		JLabel lblEmail = new JLabel("E-Mail");
		lblEmail.setForeground(Color.BLACK);
		lblEmail.setBounds(259, 622, 64, 14);
		contentPane.add(lblEmail);
		
		txtem = new JTextField();
		txtem.setColumns(10);
		txtem.setBounds(333, 619, 127, 20);
		contentPane.add(txtem);
		
		txtds3 = new JTextField();
		txtds3.setColumns(10);
		txtds3.setBounds(1064, 555, 127, 20);
		contentPane.add(txtds3);
		
		JLabel lblDataSaida = new JLabel("Data Saida");
		lblDataSaida.setForeground(Color.BLACK);
		lblDataSaida.setBounds(995, 558, 69, 14);
		contentPane.add(lblDataSaida);
		
		JLabel lblRfid = new JLabel("RFID");
		lblRfid.setForeground(Color.BLACK);
		lblRfid.setBounds(995, 524, 64, 14);
		contentPane.add(lblRfid);
		
		txtnserie3 = new JTextField();
		txtnserie3.setColumns(10);
		txtnserie3.setBounds(1064, 521, 127, 20);
		contentPane.add(txtnserie3);
		
		txtpos3 = new JTextField();
		txtpos3.setColumns(10);
		txtpos3.setBounds(1064, 588, 127, 20);
		contentPane.add(txtpos3);
		
		JLabel lblPosicao = new JLabel("Posicao");
		lblPosicao.setForeground(Color.BLACK);
		lblPosicao.setBounds(995, 591, 69, 14);
		contentPane.add(lblPosicao);
	}
	public static void DisplayDB() {
		try {
			Connection conobj = getConnection();
			Statement stmt = conobj.createStatement();
			String query = "SELECT * FROM `contt`";
			ResultSet rs = stmt.executeQuery(query);		
			String[] columnNames = {"RFID", "Propietario", "Est. Chegada", "Peso", "Conteudo", "Tipo", "TEUs", "E-Mail"};
			DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
			table_2.setModel(tableModel);
			while (rs.next()) {
			int s = rs.getInt("n_serie");
			String p = rs.getString("propiet");
			String ec = rs.getString("est_cheg");
			float pe = rs.getFloat("peso");
			String c = rs.getString("cont");
			String t = rs.getString("tipo");
			int te = rs.getInt("teus");
			String em = rs.getString("email");
			tableModel.addRow(new Object[]{s, p, ec, pe, c, t, te, em});
			}
			table_2.setRowHeight(40);
			table_2.getColumnModel().getColumn(2).setPreferredWidth(100);
			table_2.getColumnModel().getColumn(4).setPreferredWidth(100);
			table_2.getColumnModel().getColumn(7).setPreferredWidth(150);
		}catch(Exception e){System.out.println(e);}
		finally{System.out.println("Function Complete");};
	}
	
	public static void DisplayDB2() {
		try {
			Connection conobj3 = getConnection();
			Statement stmt3 = conobj3.createStatement();
			String query3 = "SELECT * FROM `contp`";
			ResultSet rs3 = stmt3.executeQuery(query3);		
			String[] columnNames3 = {"RFID", "Propietario", "Peso", "Conteudo", "Tipo", "TEUs", "Data Chegada", "Posicao", "E-Mail", "Data Saida"};
			DefaultTableModel tableModel3 = new DefaultTableModel(columnNames3, 0);
			table_3.setModel(tableModel3);
			while (rs3.next()) {
			int s3 = rs3.getInt("n_serie2");
			String p3 = rs3.getString("propiet2");
			float pe3 = rs3.getFloat("peso2");
			String c3 = rs3.getString("cont2");
			String t3 = rs3.getString("tipo2");
			int te3 = rs3.getInt("teus2");
			String dc3 = rs3.getString("data_cheg2");
			String pos3 = rs3.getString("pos2");
			String email3 = rs3.getString("email2");
			String data_s3 = rs3.getString("data_s2");
			tableModel3.addRow(new Object[]{s3, p3, pe3, c3, t3, te3, dc3, pos3, email3, data_s3});
			}
			table_3.setRowHeight(40);
			table_3.getColumnModel().getColumn(3).setPreferredWidth(100);
			table_3.getColumnModel().getColumn(8).setPreferredWidth(150);
			table_3.getColumnModel().getColumn(6).setPreferredWidth(150);
		}catch(Exception e){System.out.println(e);}
		finally{System.out.println("Function Complete");};
	}
}