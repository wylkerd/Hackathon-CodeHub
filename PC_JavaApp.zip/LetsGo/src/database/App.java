package database;
//PROGRAMA DESENVOLVIDO POR: 
//WYLKERD SANTOS SILVA / RA: N294HH-0 / TURMA: CC4A41
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class App extends JFrame {

	private JPanel contentPane;
	private JTextField tfLogin;
	private JTextField tfSenha;
	
	public void limparCampos(){
		tfLogin.setText("");
		tfSenha.setText("");
	}

	Atentica�ao autenticar = new Atentica�ao();
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					App frame = new App();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public App() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnunciado = new JLabel("Login para acessar o sistema");
		lblEnunciado.setBounds(103, 24, 242, 14);
		contentPane.add(lblEnunciado);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setBounds(141, 75, 46, 14);
		contentPane.add(lblLogin);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(141, 100, 46, 14);
		contentPane.add(lblSenha);
		
		tfLogin = new JTextField();
		tfLogin.setBounds(197, 72, 120, 20);
		contentPane.add(tfLogin);
		tfLogin.setColumns(10);
		
		tfSenha = new JTextField();
		tfSenha.setBounds(197, 97, 120, 20);
		contentPane.add(tfSenha);
		tfSenha.setColumns(10);
		
		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String login = tfLogin.getText();
				String senha = tfSenha.getText();
				autenticar.setIn_login(login);
				autenticar.setIn_Senha(senha);
				autenticar.verAutentica�ao();
				
			}
		});
		btnEntrar.setBounds(169, 148, 89, 23);
		contentPane.add(btnEntrar);
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 limparCampos();
			}
		});
		btnLimpar.setBounds(236, 228, 89, 23);
		contentPane.add(btnLimpar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnSair.setBounds(335, 228, 89, 23);
		contentPane.add(btnSair);
	}

}